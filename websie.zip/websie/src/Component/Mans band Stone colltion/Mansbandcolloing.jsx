// import React from "react";
// import Navbarpage from '../Homepage/Navbarpage/Navbarpage'
// import MansFiltterBandsnew from "./mans Filtter  bands new/MansFiltterBandsnew";
// import MansProductmetal from './Mans only product page/MansProductmetal'
// import GemstoneBandsRing from '../Fine Jewelry Collection Gemstone BandS/Gemstone Ring Bands/GemstoneBandsRing'
// import Footer from '../Homepage/Footer/Footer'

// const Mansbandcolloing = () => {
//   return (
//     <>
//       <Navbarpage />
//       <MansFiltterBandsnew/>
//       <GemstoneBandsRing/>
//       <MansProductmetal/>
//       <Footer/>
    
//     </>
//   );
// };

// export default Mansbandcolloing;
