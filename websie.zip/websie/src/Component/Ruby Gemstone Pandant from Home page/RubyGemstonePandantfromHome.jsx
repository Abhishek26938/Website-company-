import React from 'react'
import Navbarpage from '../Homepage/Navbarpage/Navbarpage'

import BlueSapphireRingprodcutinhome from '../Blue sapphire fold in home page link/Blue sapphire Ring product page in home/BlueSapphireRingprodcutinhome'
import BlueSapphireRingHomePageLink from '../Blue sapphire fold in home page link/Blue sapphire Ring  Product/BlueSapphireRingHomePagelink'
import Footer from '../Homepage/Footer/Footer'
import RubyGemstonePandantprodcutf from './Ruby Gemstone Pandant Product file/RubyGemstonePandantprodcutf'

const RubyGemstonePandantfromHome = () => {
  return (
    <>
     <Navbarpage/>
     <BlueSapphireRingHomePageLink/>
    <RubyGemstonePandantprodcutf/>
     <Footer/>
    </>
  )
}

export default RubyGemstonePandantfromHome
