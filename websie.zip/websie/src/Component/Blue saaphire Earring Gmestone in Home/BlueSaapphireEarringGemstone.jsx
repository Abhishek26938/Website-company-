import React from "react";
import Navbarpage from "../Homepage/Navbarpage/Navbarpage";
import BlueSapphireRingHomePagelink from "../Blue sapphire fold in home page link/Blue sapphire Ring  Product/BlueSapphireRingHomePagelink";
import Footer from "../Homepage/Footer/Footer";
import BlueSapphireEarringProdcutgem from "./Blue sapphire Earring product from home page gem/BlueSapphireEarringProdcutgem";

const BlueSaapphireEarringGemstone = () => {
  return (
    <>
      <Navbarpage />
      <BlueSapphireRingHomePagelink />
      <BlueSapphireEarringProdcutgem />
      <Footer />
    </>
  );
};

export default BlueSaapphireEarringGemstone;
