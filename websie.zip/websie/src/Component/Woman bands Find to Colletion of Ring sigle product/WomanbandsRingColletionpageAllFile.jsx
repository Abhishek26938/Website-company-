import React from 'react'
import WomanBAndspageofimageandtype from './Woman Bands page of image and type of  product/WomanBAndspageofimageandtype'
import Navbarpage from '../Homepage/Navbarpage/Navbarpage'
import WomanBandsSingleProdcutDetails from './Woman bands single product page product Details/WomanBandsSingleProdcutDetails'
import ImportantFact from '../OneProduct/Important Facts/ImportantFact'
import WomadBAndsTextProduct from './Woman Bands About of text product/WomadBAndsTextProduct'
import Footer from '../Homepage/Footer/Footer'

const WomanbandsRingColletionpageAllFile = () => {
  return (
    <>
    <Navbarpage/>
      <WomanBAndspageofimageandtype/>
      <WomanBandsSingleProdcutDetails/>
      <ImportantFact/>
      <WomadBAndsTextProduct/>
      <Footer/>
   </>
  )
}

export default WomanbandsRingColletionpageAllFile
