import React from 'react'

const WomanBandsSingleProdcutDetails = () => {
  return (
    <>
         <div className="Single_product-detail-div-in-info">
        <div className="single-product-div-prodcut-deatails">
          <h3>Product Details</h3>
         
        </div>
        <div className="div-detail-in-product-item">
          <div className="item-single-prodcut-ring-detail">
            <h5>PRODUCT SPECIFICATIONS:</h5>
            <div className="item-single-product-ring-new">
              <span className="detailbox-info-pro">
                Item #: <span style={{ color: "black" }}> RBS082-5X5-A</span>
              </span>
              <span className="detailbox-info-pro">
                Metal: <span style={{ color: "black" }}>Silver</span>
              </span>
              <span className="detailbox-info-pro">
                Prong Metal: <span style={{ color: "black" }}>Silver</span>
              </span>
              <span className="detailbox-info-pro">
                Rhodium: <span style={{ color: "black" }}>No</span>
              </span>
              <span className="detailbox-info-pro">
                Prong Style: <span style={{ color: "black" }}>Classic</span>
              </span>
              <span className="detailbox-info-pro">
                Ring Width (Widest Point):{" "}
                <span style={{ color: "black" }}> 2.03mm (Dainty)</span>
              </span>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default WomanBandsSingleProdcutDetails
