import React from 'react'

const WomadBAndsTextProduct = () => {
  return (
    <>
      <p style={{margin: "30px"}}>A metal band is an accessory for a man that goes perfectly well with all his outfits. Choose one from our collection of beautifully crafted metal bands for men. You can also customize your band with a message or quote which we'll engrave for you. Moreover, you can also use combination of metals.</p>
    </>
  )
}

export default WomadBAndsTextProduct
