// import React from 'react'

// const Allgemstonenewer = (props) => {
//   return (
//     <>
// {/*---------------------------------------- Shop Rings By Gemstone -----------------------------------------------*/}
//   {/*---------------------------------------- Shop Rings By Gemstone -----------------------------------------------*/}
//   <div className="ring-by">
//     <h3>Shop {props.name} By Gemstone</h3>
//     <div className="ring-byshop-name">
//      {props.discription}
//     </div>
//   </div>

//     </>
//   )
// }

// export default Allgemstonenewer
