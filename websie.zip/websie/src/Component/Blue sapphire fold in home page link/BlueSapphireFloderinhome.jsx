import React from 'react'
import Navbarpage from '../Homepage/Navbarpage/Navbarpage'
import BlueSapphireRingHomePagelink from './Blue sapphire Ring  Product/BlueSapphireRingHomePagelink'
import  BlueSapphireRingprodcutinhome from './Blue sapphire Ring product page in home/BlueSapphireRingprodcutinhome'
import Footer from '.././Homepage/Footer/Footer'

const BlueSapphireFloderinhome = () => {
  return (
    <>
      <Navbarpage/>
      <BlueSapphireRingHomePagelink/>
      < BlueSapphireRingprodcutinhome/>
      <Footer/>
      
    </>
  )
}

export default BlueSapphireFloderinhome
