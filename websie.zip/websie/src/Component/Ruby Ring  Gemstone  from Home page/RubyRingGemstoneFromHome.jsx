import React from "react";
import Navbarpage from "../Homepage/Navbarpage/Navbarpage";
import ImportantFact from "../OneProduct/Important Facts/ImportantFact";
import Footer from "../Homepage/Footer/Footer";
import RubyRingAboutofRinginText from "./Ruby Ring About of ring in Text/RubyRingAboutofRinginText";
import RubyRingGemstoneFromimageanDetail from "./Ruby Ring Gemstone From product page/RubyRingGemstoneFromimageanDetail";
import RubyCookeisProductRing from "./Ruby Ring Cookeies Product from/RubyCookeisProductRing";
import RubyRingFromProductimageDetails from "./Ruby Ring from prodcut image details/RubyRingFromProductimageDetails";

const RubyRingGemstoneFromHome = () => {
  return (
    <>
      <Navbarpage />
      <RubyRingGemstoneFromimageanDetail />
      <RubyCookeisProductRing />
      <RubyRingFromProductimageDetails />
      <ImportantFact />
      <RubyRingAboutofRinginText />
      <Footer />
    </>
  );
};

export default RubyRingGemstoneFromHome;
