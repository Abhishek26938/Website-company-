import React from 'react'

const RubyRingAboutofRinginText = () => {
  return (
    <>
       <p className='What-sthe-classic-sapphire' >Find the perfect ring today for the love of your life in our huge collection of preset ruby rings. Customize ring metal, size of the stone and style. If you have anything unique in your mind, our experts will bring it to life. Choose a metal - 14k/18k gold or platinum. Explore our charming offers.</p>
    </>
  )
}

export default RubyRingAboutofRinginText

