
 export const FAQsrtring  = [
        {
            id : "1",
            question : " What makes a sapphire blue? " ,
            answer : "Trace amounts of iron and titanium within the corundum mineral cause the captivating blue hues of a sapphire."
        }
        , {
            id : "2",
            question : "What's the most coveted blue sapphire color? " ,
            answer : "The cornflower blue, known for its intense and pure blue brilliance, is the most sought-after shade."
        }
        ,
        {
            id : "3",
            question : " Are blue sapphires a popular choice for weddings? " ,
            answer : "Yes! Modern weddings often incorporate blue sapphires in engagement rings, stackable bands, and 'something blue' accents. Princess Diana's iconic ring is a prime example."
        }
        ,
        {
            id : "4",
            question : "Can I buy a loose blue sapphire? " ,
            answer : "Absolutely! Loose gemstones offer the opportunity to design your own unique piece of jewelry."    
        }
         
        , {
            id : "5",
            question : " What symbolic connotations are linked with blue sapphires? " ,
            answer : "Blue sapphire is associated with wisdom, truth, loyalty, and nobility."
        }
        , {
            id : "6",
            question : "Where do blue sapphires come from?  " ,
            answer : "Sri Lanka, Madagascar, Myanmar, and Kashmir (India) are some of the most famous sources, but blue sapphires can be found worldwide."
        }
    ]
    


