import React from 'react'
import Navbarpage from '../Homepage/Navbarpage/Navbarpage'
import BlueSapphireRingprodcutinhome from '../Blue sapphire fold in home page link/Blue sapphire Ring product page in home/BlueSapphireRingprodcutinhome'
import BlueSapphireRingHomePagelink  from '../Blue sapphire fold in home page link/Blue sapphire Ring  Product/BlueSapphireRingHomePagelink'
import Footer from '../Homepage/Footer/Footer'
import RubySappireproductRingFile from './Ruby sappire Stone Filter in Home page/RubySappireproductRingFile'

const RubySapphireStoneinHome = () => {
  return (
    <>
     <Navbarpage/>
     <BlueSapphireRingHomePagelink/>
     <RubySappireproductRingFile/>
     <Footer/>
    </>
  )
}

export default RubySapphireStoneinHome
