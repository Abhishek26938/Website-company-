import React from "react";

const Manbandsjewellerysingleproducttext = () => {
  return (
    <>
     <p style={{margin: "30px"}}> A metal band is an accessory for a man that goes perfectly well with all
      his outfits. Choose one from our collection of beautifully crafted metal
      bands for men. You can also customize your band with a message or quote
      which we'll engrave for you. Moreover, you can also use combination of
      metals. Subscribe to Texts Receive $50 off* Subscribe Now- Learn More For
      Subscribe To Texts *See Terms Refer a Friend - You Get $75</p>
    </>
  );
};

export default Manbandsjewellerysingleproducttext;
