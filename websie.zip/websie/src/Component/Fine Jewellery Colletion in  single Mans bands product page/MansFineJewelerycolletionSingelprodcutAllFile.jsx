import React from 'react'
import ManbandsSingleProductimageandtype from './Man bands  single product image and type of product/ManbandsSingleProductimageandtype'
import Navbarpage from '../Homepage/Navbarpage/Navbarpage'
import MansBandsSingleprodcutimageDetails from './Mans Colletion product detail and ring product/MansBandsSingleprodcutimageDetails'
import ImportantFact from '../OneProduct/Important Facts/ImportantFact'
import Manbandsjewellerysingleproducttext from "./man single page text about of image product in/Manbandsjewellerysingleproducttext"
import Footer from '../Homepage/Footer/Footer'

const MansFineJewelerycolletionSingelprodcutAllFile = () => {
  return (
    <>
    <Navbarpage/>
< ManbandsSingleProductimageandtype/>
<MansBandsSingleprodcutimageDetails/>
<ImportantFact/>
<Manbandsjewellerysingleproducttext/>
<Footer/>

    </>
  )
}

export default MansFineJewelerycolletionSingelprodcutAllFile
