import React from 'react'

const EmeraldearringGemstoneTextinProdcut = () => {
  return (
    <>
      <p style={{margin:"30px"}}>Add a flavor of sophistication to your style with a pair of refreshing green emerald earrings. What's the whole point of accessorizing? To add glamor to one’s look! So, what are you waiting for? Invest in the charming green emerald earrings to look magnificent at all times. Also, see our offers.</p>
    </>
  )
}

export default EmeraldearringGemstoneTextinProdcut
