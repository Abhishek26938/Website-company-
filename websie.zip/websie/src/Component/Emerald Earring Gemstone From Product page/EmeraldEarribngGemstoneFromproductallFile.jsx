import React from "react";
import EmeraldEarringGemstoneimageandtypeDetails from "./Emerald Earring Gemstone image and type Gemstone/EmeraldEarringGemstoneimageandtypeDetails";
import Navbarpage from "../Homepage/Navbarpage/Navbarpage";
import EmeraldEarringGemstoneCookiesProduct from "./Emerald Earring Gemstone Coockies product/EmeraldEarringGemstoneCookiesProduct";
import EmeraldEarringGemstoneAboutofpro from "./Emerald Earring Gemstone about of product/EmeraldEarringGemstoneAboutofpro";
import ImportantFact from "../OneProduct/Important Facts/ImportantFact";
import EmeraldearringGemstoneTextinProdcut from "./Emerald Earring Gemstone text in product/EmeraldearringGemstoneTextinProdcut";
import Footer from "../Homepage/Footer/Footer";

const EmeraldEarribngGemstoneFromproductallFile = () => {
  return (
    <>
      <Navbarpage />
      <EmeraldEarringGemstoneimageandtypeDetails />
      <EmeraldEarringGemstoneCookiesProduct />
      <EmeraldEarringGemstoneAboutofpro />
      <ImportantFact />
      <EmeraldearringGemstoneTextinProdcut />
      <Footer />
    </>
  );
};

export default EmeraldEarribngGemstoneFromproductallFile;
