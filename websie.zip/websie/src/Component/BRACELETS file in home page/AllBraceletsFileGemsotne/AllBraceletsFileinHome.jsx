import React from "react";
import Allgemstonenewer from "../../Commonnd/Gesmtoneshopall/Allgemstonenewer";

const AllBraceletsFileinHome = () => {
  return (
    <>
      <Allgemstonenewer
        name="Earring"
        discription="Shop Earrings By Gemstone
A breathtaking variety of earrings on sale. Buy gemstone stud earrings online with confidence from our inventory of over 50000 certified gemstones"
      />{" "}
    </>
  );
};

export default AllBraceletsFileinHome;
