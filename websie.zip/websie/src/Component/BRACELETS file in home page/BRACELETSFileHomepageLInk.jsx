import React from 'react'
import Navbarpage from "../Homepage/Navbarpage/Navbarpage"
import Brealetsofthebackgroundimage from './Braclets of header background/Brealetsofthebackgroundimage.'
import Fixcebleprinceline from '.././Ringproductimagepage/fixcebleprince/Fixcebleprinceline'
import AllBraceletsFileinHome from './AllBraceletsFileGemsotne/AllBraceletsFileinHome'
import GemstoneallImagestone from '.././Ringproductimagepage/Gemstoneallimagestone/GemstoneallImagestone'
import Butdirectnomiddle from '.././Ringproductimagepage/BuyDirectNoMiddle/Butdirectnomiddle'
import ShoppopularBralslete from './Shoppopularinbracelets/ShoppopularBralslete'
import Flexiblefinancingpagenewringpage from '../Ringproductimagepage/flexiblefinancingnewpage/Flexiblefinancingpagenewringpage'
import ShopmetalpageRing from '../Ringproductimagepage/ShopMetalRingPage/ShopmetalpageRing'
import ConsultOurJewleryRingPage from '../Ringproductimagepage/Consult Our Jewelry/ConsultOurJewleryRingPage'
import Footer from '../Homepage/Footer/Footer'


const BRACELETSFileHomepageLInk = () => {
  return (
    <>
    <Navbarpage/>
    <Brealetsofthebackgroundimage />
    <Fixcebleprinceline/>
    <AllBraceletsFileinHome/>
    <GemstoneallImagestone/>
    <Butdirectnomiddle/>
    <ShoppopularBralslete/>
    <Flexiblefinancingpagenewringpage/>
    <ShopmetalpageRing/>
    <ConsultOurJewleryRingPage/>
    <Footer/>
    

    </>
  )
}

export default BRACELETSFileHomepageLInk
