export const BraceletDdata = [{
    id : "1" ,
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/popularsettings/bracelets/BR141.jpg?format=webp",
    ProdcutLink : "/BralcelesSingleprodcutallFile"
},
{
    id : "2" ,
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/popularsettings/bracelets/BR141.jpg?format=webp",
    ProdcutLink : "/BralcelesSingleprodcutallFile"

},
{
    id : "3" ,
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/popularsettings/bracelets/BR141.jpg?format=webp",
    ProdcutLink : "/"

},
{
    id : "4" ,
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/popularsettings/bracelets/BR141.jpg?format=webp",
    ProdcutLink : "/"

},
{
    id : "5" ,
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/popularsettings/bracelets/BR141.jpg?format=webp",
    ProdcutLink : "/"

},
{
    id : "6" ,
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/popularsettings/bracelets/BR141.jpg?format=webp",
    ProdcutLink : "/"

},
{
    id : "7" ,
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/popularsettings/bracelets/BR141.jpg?format=webp",
    ProdcutLink : "/"

},
{
    id : "8" ,
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/popularsettings/bracelets/BR141.jpg?format=webp",
    ProdcutLink : "/"

},
{
    id : "9" ,
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/popularsettings/bracelets/BR141.jpg?format=webp",
    ProdcutLink : "/"

},
{
    id : "10" ,
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/popularsettings/bracelets/BR141.jpg?format=webp",
    ProdcutLink : "/"

},


]
