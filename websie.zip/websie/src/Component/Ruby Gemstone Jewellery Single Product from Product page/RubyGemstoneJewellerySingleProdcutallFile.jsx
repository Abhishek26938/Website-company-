import React from "react";
import RubyGemstoneJewelleryimageandtypeofProduct from "./Ruby Gemstone Jewellery image and type of product/RubyGemstoneJewelleryimageandtypeofProduct";
import Navbarpage from "../Homepage/Navbarpage/Navbarpage";
import RubyGemstonePandantCookiesProdcut from './Ruby Gemstone pandant  Cookies Product/RubyGemstonePandantCookiesProdcut'
import RubyGemstoneJweweleryPandantaboutpro from './Ruby Gemstone Jewellery About of Product/RubyGemstoneJweweleryPandantaboutpro'
import ImportantFact from "../OneProduct/Important Facts/ImportantFact";
import Footer from "../Homepage/Footer/Footer";

const RubyGemstoneJewellerySingleProdcutallFile = () => {
  return (
    <>
      <Navbarpage />
      <RubyGemstoneJewelleryimageandtypeofProduct />
      <RubyGemstonePandantCookiesProdcut/>
      <RubyGemstoneJweweleryPandantaboutpro/>
      <ImportantFact/>
        <Footer/>
    </>
  );
};

export default RubyGemstoneJewellerySingleProdcutallFile;
