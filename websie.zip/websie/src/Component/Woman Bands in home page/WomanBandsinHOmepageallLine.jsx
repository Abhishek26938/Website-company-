import React from 'react'
import Navbarpage from '../Homepage/Navbarpage/Navbarpage'
import WomaBandsHomeLink  from "./Woman Bands Filter  in  Link Home page/WomaBandsHomeLink"
import MansFiltterBandsnew from '../Mans band Stone colltion/mans Filtter  bands new/MansFiltterBandsnew'
import GemstoneBandsRing from '../Fine Jewelry Collection Gemstone BandS/Gemstone Ring Bands/GemstoneBandsRing'
import Footer from '../Homepage/Footer/Footer'

const WomanBandsinHOmepageallLine = () => {
  return (
    <>
    <Navbarpage/>
    <MansFiltterBandsnew/>
    <GemstoneBandsRing/>
    <WomaBandsHomeLink/>
    <Footer/>
    </>
  )
}

export default WomanBandsinHOmepageallLine
