import React from 'react'
import Gemstonbandspageofinglepagealld from './Gemstone Bands all image and detailsin product/Gemstonbandspageofinglepagealld'
 import Navberpage from '../Homepage/Navbarpage/Navbarpage'
import GemstoneBandsproductimge from './Gemstone Bands of All Prodcut image detail/GemstoneBandsproductimge'
import ImportantFact from '../OneProduct//Important Facts/ImportantFact'
import Footer from '../Homepage/Footer/Footer'
import Gemstonebandsofimagesonte from './Gemstone beands of single product text/Gemstonebandsofimagesonte'

const GemstoneBandsproductallFilesto = () => {
  return (
    <>
    <Navberpage/>
      <Gemstonbandspageofinglepagealld/>
      <GemstoneBandsproductimge/>
      <ImportantFact/>
      <Gemstonebandsofimagesonte/>
      <Footer/>
    </>
  )
}

export default GemstoneBandsproductallFilesto
