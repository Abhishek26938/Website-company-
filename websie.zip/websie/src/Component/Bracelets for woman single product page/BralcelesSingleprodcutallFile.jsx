import React from "react";
import BraceletsForWomanSingleProdcutimagetype from "./Bracelets For woman single Prodcut type of imge/BraceletsForWomanSingleProdcutimagetype";
import Navbarpage from "../Homepage/Navbarpage/Navbarpage";
import Braceletsingelprodcutaboutproduct from './Bracelets for woman single prodcut about product/Braceletsingelprodcutaboutproduct'
// import ImportantFact from "../OneProduct/Important Facts/ImportantFact";
import Footer from "../Homepage/Footer/Footer";


const BralcelesSingleprodcutallFile = () => {
  return (
    <>
      <Navbarpage />
      <BraceletsForWomanSingleProdcutimagetype /> 
      <Braceletsingelprodcutaboutproduct/>
      {/* <ImportantFact/> */}
      <Footer/>
   
    </>
  );
};

export default BralcelesSingleprodcutallFile;
