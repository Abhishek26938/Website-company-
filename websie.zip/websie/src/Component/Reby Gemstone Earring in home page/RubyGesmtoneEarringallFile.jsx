import React from 'react'
import Navbarpage from '../Homepage/Navbarpage/Navbarpage'
import BlueSapphireRingHomePagelink from '../Blue sapphire fold in home page link/Blue sapphire Ring  Product/BlueSapphireRingHomePagelink'
import  BlueSapphireRingprodcutinhome from '../Blue sapphire fold in home page link/Blue sapphire Ring product page in home/BlueSapphireRingprodcutinhome'
import Footer from '../Homepage/Footer/Footer'
import RubyGemstoneProductfile from './Ruby Gemstone Product Earring/RubyGemstoneProductfile'

const RubyGesmtoneEarringallFile = () => {
  return (
    <>
    <Navbarpage/>
    <BlueSapphireRingHomePagelink/>
    < RubyGemstoneProductfile/>
    <Footer/>
    </>
  )
}

export default RubyGesmtoneEarringallFile
