import React from 'react'
import './Presetcolletionimage.css'
import Imagesringpendantearring from  "../../Commonnd/Imagesofearringringpandand/Imagesringpendantearring"

const Presetcolletionimage = () => {
  return (
    <>
 <Imagesringpendantearring 
  Name = "Ring" Description = "Buy rings online from our curated collection of popular diamond, sapphire, ruby and emerald rings. Our interface lets you easily create your rings." 
      visite1 ="/"  Name1="Sapphire Rings" image1 ="https://d3kinlcl20pxwz.cloudfront.net/images/home_new/preset-rings-three-rings-sapphire-solitaire.jpg?format=webp" 
      visite2 ="/"  Name2="Ruby Ring " image2 ="https://d3kinlcl20pxwz.cloudfront.net/imgs/main/preset-rings-three-rings-ruby-sidestone.webp"
      visite3 ="/"  Name3="Emerald" image3 ="https://d3kinlcl20pxwz.cloudfront.net/imgs/main/preset-rings-three-rings-emerald-solitaire2.webp"
      />
    </>
  )
}

export default Presetcolletionimage
