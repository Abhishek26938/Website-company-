import React from 'react'
import './Consultrourjewlleryring.css'

const ConsultOurJewleryRingPage = () => {
  return (
    <>
      <div className="consult-our-jewellery">
        <div className="consult-our-jewelery">
          <div className="Jewellery-contect">
            <h3>Consult Our Jewelry Specialists</h3>
            <p>A more thoughtful way to experience fine jewelry, built around you.</p>
            <div className="Ring-page-contect-costumar">
              <div className="div-ring-call">
              <i class="fa-solid fa-phone"></i>
              <p>1-888-436-7692</p>
              </div>
              <div className="div-ring-call">
              <i class="fa-solid fa-comments"></i>
              <p>Live Chat</p>
              </div>
              <div className="div-ring-call">
              <i class="fa-solid fa-envelope"></i>
              <p>Email</p>
              </div>
            </div>
            <button  className=" vistie-ring-page">Visite Showroom</button>
          </div>
        </div>
        <img className='office-imagepin' src="https://d3kinlcl20pxwz.cloudfront.net/imgs/lp/cunsult_img.webp" alt="" />
      </div>
    </>
  )
}

export default ConsultOurJewleryRingPage
