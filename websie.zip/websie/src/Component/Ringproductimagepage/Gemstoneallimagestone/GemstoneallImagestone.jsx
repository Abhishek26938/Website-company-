import React from 'react'
import './GemstoneallImg.css'

const GemstoneallImagestone = () => {
  return (
    <>
      <>
  {/*---------------------------------------- gemstone image-ring page ----------------------------------------------*/}
  {/*---------------------------------------- gemstone image-ring page ----------------------------------------------*/}
  <div className="Gemstone-spphire-Ring">
    <div className="spphire-image">
      <div className="imge-spphire-new">
        <img
          src="https://d3kinlcl20pxwz.cloudfront.net/assets/images/gemstone/sapphires.jpg?format=webp"
          alt=""
        />
        <span>sapphire</span>
      </div>
      <div className="imge-spphire-new">
        <img
          src="https://d3kinlcl20pxwz.cloudfront.net/assets/images/gemstone/ruby.jpg?format=webp"
          alt=""
        />
        <span>sapphire</span>
      </div>
      <div className="imge-spphire-new">
        <img
          src="https://d3kinlcl20pxwz.cloudfront.net/assets/images/gemstone/emerald.jpg?format=webp"
          alt=""
        />
        <span>Emeralds</span>
      </div>
      <div className="imge-spphire-new">
        <img
          src="https://d3kinlcl20pxwz.cloudfront.net/assets/images/gemstone/alexandrite.jpg?format=webp"
          alt=""
        />
        <span>Alexandrites</span>
      </div>
    </div>
  </div>
  <div className="spphire-image">
    <div className="imge-spphire-new">
      <img
        src="https://d3kinlcl20pxwz.cloudfront.net/assets/images/gemstone/tanzanites.jpg?format=webp"
        alt=""
      />
      <span>Tanzanites</span>
    </div>
    <div className="imge-spphire-new">
      <img
        src="https://d3kinlcl20pxwz.cloudfront.net/assets/images/gemstone/tsavorite.jpg?format=webp"
        alt=""
      />
      <span>Tsavorites</span>
    </div>
    <div className="imge-spphire-new">
      <img
        src="https://d3kinlcl20pxwz.cloudfront.net/assets/images/gemstone/aquamarine.jpg?format=webp"
        alt=""
      />
      <span>Aquamarines</span>
    </div>
    <div className="imge-spphire-new">
      <img
        src="https://d3kinlcl20pxwz.cloudfront.net/assets/images/gemstone/pink-tourmaline.jpg?format=webp"
        alt=""
      />
      <span>Pink Tourmalines</span>
    </div>
    <div className="imge-spphire-new">
      <img
        src="https://d3kinlcl20pxwz.cloudfront.net/assets/images/gemstone/hessonite-garnet.jpg?format=webp"
        alt=""
      />
      <span>Hessonite Garnets</span>
    </div>
    <div className="imge-spphire-new">
      <img
        src="https://d3kinlcl20pxwz.cloudfront.net/assets/images/gemstone/spinel.jpg?format=webp"
        alt=""
      />
      <span>Spine</span>
    </div>
    <div className="imge-spphire-new">
      <img
        src="https://d3kinlcl20pxwz.cloudfront.net/assets/images/gemstone/peridot.jpg?format=webp"
        alt=""
      />
      <span>Peridots</span>
    </div>
    <div className="imge-spphire-new">
      <img
        src="https://d3kinlcl20pxwz.cloudfront.net/assets/images/gemstone/paraiba-tourmaline.jpg?format=webp"
        alt=""
      />
      <span>Paraiba Tourmaline</span>
    </div>
  </div>
</>

    </>
  )
}

export default GemstoneallImagestone
