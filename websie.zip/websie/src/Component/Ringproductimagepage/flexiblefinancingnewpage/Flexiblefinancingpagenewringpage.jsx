import React from 'react'

const Flexiblefinancingpagenewringpage = () => {
  return (
    <>
       {/*--------------------------------- Flexible Financing -------------------------------*/}
      {/*--------------------------------- Flexible Financing -------------------------------*/}
      <section>
        <div className="cart-pic-to-know fontsnee" style={{marginTop : "-70px"}}>
          <div className="flexibele_financing-with">
            <div className=" March-will-be">
              <div className="flexible">
                <h1>Flexible Financing</h1>
                <div className="flexible_financing_img">
                  <div className="affim">
                    <img
                      src="https://d3kinlcl20pxwz.cloudfront.net/imgs/main/affirm_icon.webp"
                      alt=""
                    />
                    <span className="mothes_month">
                      Up to 36 months financing available.
                    </span>
                    <a href="#">Learn more</a>
                  </div>
                  <div className="affim">
                    <img
                      src="https://d3kinlcl20pxwz.cloudfront.net/imgs/main/splitit_icon.webp"
                      alt=""
                    />
                    <span className="mothes_month">
                      Choose from 3, 6, 9 or 12 months interest <br /> free
                      payments at checkout.
                    </span>
                    <a href="#">Learn more</a>
                  </div>
                  <div className="affim">
                    <img
                      src="https://d3kinlcl20pxwz.cloudfront.net/imgs/main/layway_icon.webp"
                      alt=""
                    />
                    <span className="mothes_month">
                      Layaway options are available. Contact <br /> us at{" "}
                      <a href="#">info@gemsny.com</a>
                    </span>
                    <a href="#">Learn more</a>
                  </div>
                </div>
              </div>
            </div>
            <div className="learn-more-note">
              <button>Learn More</button>
              <div className="note-div-product">
                <p className="all-financing-iotion-we-be"></p>
                <h4>Note:</h4>All Financing options we be available at checkout
                <p />
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

export default Flexiblefinancingpagenewringpage

