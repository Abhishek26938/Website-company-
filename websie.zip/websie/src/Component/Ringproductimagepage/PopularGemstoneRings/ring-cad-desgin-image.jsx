export const imageRing = [{
    id : "1" ,
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/popularsettings/rings/R10694DM.jpg?format=webp"

},
{
    id : "2" ,
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/popularsettings/rings/R10694DM.jpg?format=webp"

},
{
    id : "3" ,
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/popularsettings/rings/R10694DM.jpg?format=webp"

},
{
    id : "4" ,
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/popularsettings/rings/R10694DM.jpg?format=webp"

},
{
    id : "5" ,
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/popularsettings/rings/R10694DM.jpg?format=webp"

},
{
    id : "6" ,
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/popularsettings/rings/R10694DM.jpg?format=webp"

},
{
    id : "7" ,
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/popularsettings/rings/R10694DM.jpg?format=webp"

},
{
    id : "8" ,
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/popularsettings/rings/R10694DM.jpg?format=webp"

},
{
    id : "9" ,
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/popularsettings/rings/R10694DM.jpg?format=webp"

},
{
    id : "10" ,
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/popularsettings/rings/R10694DM.jpg?format=webp"

},


]
