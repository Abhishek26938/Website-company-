export const imageData = [ {
    id : "1",
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/shopbystyle/gemstonerings/gemstone-solitaire.jpg?format=webp",
    ProName : "Solitaire",
    description : "Petite and delicate, a solitaire setting is the  epitome of timeless elegance"
},
{
    id : "2",
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/shopbystyle/gemstonerings/gemstone-solitaire.jpg?format=webp",
    ProName : "Solitaire",
    description : "Petite and delicate, a solitaire setting is the  epitome of timeless elegance"
}, {
    id : "3",
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/shopbystyle/gemstonerings/gemstone-solitaire.jpg?format=webp",
    ProName : "Solitaire",
    description : "Petite and delicate, a solitaire setting is the  epitome of timeless elegance"
}
, {
    id : "4",
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/shopbystyle/gemstonerings/gemstone-solitaire.jpg?format=webp",
    ProName : "Solitaire",
    description : "Petite and delicate, a solitaire setting is the  epitome of timeless elegance"
}
,
{
    id : "5",
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/shopbystyle/gemstonerings/gemstone-solitaire.jpg?format=webp",
    ProName : "Solitaire",
    description : "Petite and delicate, a solitaire setting is the  epitome of timeless elegance"
},
{
    id : "6",
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/shopbystyle/gemstonerings/gemstone-solitaire.jpg?format=webp",
    ProName : "Solitaire",
    description : "Petite and delicate, a solitaire setting is the  epitome of timeless elegance"
}
,
{
    id : "7",
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/shopbystyle/gemstonerings/gemstone-solitaire.jpg?format=webp",
    ProName : "Solitaire",
    description : "saesssssssing is the  epitome of timeless elegancffrrfewrdfsfdfsde"
}
, {
    id : "8",
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/shopbystyle/gemstonerings/gemstone-solitaire.jpg?format=webp",
    ProName : "Solitaire",
    description : "Petite and delicate, a solitaire setting is the  epitome of timeless elegance"
}
, {
    id : "9",
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/shopbystyle/gemstonerings/gemstone-solitaire.jpg?format=webp",
    ProName : "Solitaire",
    description : "Petite and delicate, a solitaire setting is the  epitome of timeless elegance"
}
, {
    id : "10",
    Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/shopbystyle/gemstonerings/gemstone-solitaire.jpg?format=webp",
    ProName : "Solitaire",
    description : "Petite and delicate, a solitaire setting is the  epitome of timeless elegance"
}

]


export const newtwoData = [
    {
        id : "1",
        Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/shopbystyle/gemstonerings/gemstone-threestone.jpg?format=webp",
        ProName : "Solitaire",
        description : "Petite and delicate, a solitaire setting is the  epitome of timeless elegance"
    },
    {
        id : "2",
        Image : "https://d3kinlcl20pxwz.cloudfront.net/assets/images/shopbystyle/gemstonerings/gemstone-threestone.jpg?format=webp",
        ProName : "Solitaire",
        description : "Petite and delicate, a solitaire setting is the  epitome of timeless elegance"
    },
]