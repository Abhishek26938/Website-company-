import React from "react";
import Navbarpage from "../Homepage/Navbarpage/Navbarpage";
import Ringimagefolder from "./RingProdcutfimag/Ringimagefolder";
import Fixcebleprinceline from "./fixcebleprince/Fixcebleprinceline";
import ShopbyRinggemstone from "./ShopRingbyGemstone/ShopbyRinggemstone";
import GemstoneallImagestone from "./Gemstoneallimagestone/GemstoneallImagestone";
import Presetcolletionimage from "./Presetcolletionimage/Presetcolletionimage";
import ShopbyStyleSheetimage from "./ShopbyStylesheet/ShopbyStyleSheetimage";
import Butdirectnomiddle from "./BuyDirectNoMiddle/Butdirectnomiddle";
import PopularGemstonering from "./PopularGemstoneRings/PopularGemstonering";
import Flexiblefinancingpagenewring from "./flexiblefinancingnewpage/Flexiblefinancingpagenewringpage";
import ShopmetalpageRing from "./ShopMetalRingPage/ShopmetalpageRing";
import ConsultOurJewleryRingPage from "./Consult Our Jewelry/ConsultOurJewleryRingPage";
import Footer from "../Homepage/Footer/Footer";

const Ringimagemailfolder = () => {
  return (
    <>
      <Navbarpage />
      <Ringimagefolder />
      <Fixcebleprinceline />
      <ShopbyRinggemstone />
      <GemstoneallImagestone />
      <Presetcolletionimage />
      <ShopbyStyleSheetimage />
      <Butdirectnomiddle />
      <PopularGemstonering />
      <ShopmetalpageRing />
      <ConsultOurJewleryRingPage />
      <Footer />
    </>
  );
};

export default Ringimagemailfolder;
