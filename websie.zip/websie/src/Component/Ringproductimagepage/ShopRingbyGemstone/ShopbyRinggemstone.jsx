import React from 'react'
import './ShopbyRingGemstone.css'
import Allgemstonenewer from "../../Commonnd/Gesmtoneshopall/Allgemstonenewer"

const ShopbyRinggemstone = () => {
  return (
    <>
     <Allgemstonenewer name= "ring" discription= "Pick your favorite gemstone ring from our inventory of over 50000 certified gemstones sourced ethically. Buy rings online with confidence. Contact our experts to discuss specific natural color stone rings or gemstones in real time"  />

</>

    
  )
}

export default ShopbyRinggemstone
