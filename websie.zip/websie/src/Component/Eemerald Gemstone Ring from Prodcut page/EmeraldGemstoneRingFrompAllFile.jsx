import React from "react";
import EmeraldGemsotneRingimgeAndDetails from "./Emerald Gemstone Ring image And Details/EmeraldGemsotneRingimgeAndDetails";
import Navbarpage from "../Homepage/Navbarpage/Navbarpage";
import EmeraldGemstoneCookeisProduct from './Emerald Gemstone cookeis Product Ring/EmeraldGemstoneCookeisProduct'
import EmeraldGemstoneRingaboutproduct from './Emerald Gemstone Ring about of product/EmeraldGemstoneRingaboutproduct'
// import ImportantFact from "../OneProduct/Important Facts/ImportantFact";
import EmraldGemstoneRingTextpro from './Emerald Gemstone Ring text Prodcut/EmraldGemstoneRingTextpro'
import Footer from "../Homepage/Footer/Footer";
const EmeraldGemstoneRingFrompAllFile = () => {
  return (
    <>
      <Navbarpage />
      <EmeraldGemsotneRingimgeAndDetails />
      <EmeraldGemstoneCookeisProduct/>
      <EmeraldGemstoneRingaboutproduct/>
      {/* <ImportantFact/> */}
      <EmraldGemstoneRingTextpro/>
      <Footer/>
    </>
  );
};

export default EmeraldGemstoneRingFrompAllFile;
