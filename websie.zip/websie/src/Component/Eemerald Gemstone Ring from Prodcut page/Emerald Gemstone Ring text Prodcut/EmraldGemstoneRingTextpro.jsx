// import React from 'react'

// const EmraldGemstoneRingTextpro = () => {
//   return (
//     <>
//       <div style={{margin: "30px"}}>If your SO likes her accessories bold, graceful and neat then preset emerald rings are your calling. With this stunning adornment on her hand, let the effervescence and vivacity of your beloved spread! The green gemstone will make her feel like the queen herself! Spread your love with emeralds.</div>
//     </>
//   )
// }

// export default EmraldGemstoneRingTextpro
