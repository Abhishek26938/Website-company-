import React from "react";
import Navbarpage from "../Homepage/Navbarpage/Navbarpage";
import BlueSapphireRingHomePagelink from '../Blue sapphire fold in home page link/Blue sapphire Ring  Product/BlueSapphireRingHomePagelink'
import BlueSapphireRingprodcutinhome from '../Blue sapphire fold in home page link/Blue sapphire Ring product page in home/BlueSapphireRingprodcutinhome'
import Footer from "../Homepage/Footer/Footer";
import EmeraldEArringGemstone from './Emerald Earring Gemstone product/EmeraldEArringGemstone'
import EmeraldGemstonePandantpro from './Emerald Earring Gemstone product/EmeraldEArringGemstone'

const EmeraldGemstoneEarrngHomepg = () => {
  return <>
  <Navbarpage/>
  <BlueSapphireRingHomePagelink/>
<EmeraldGemstonePandantpro/>
  <Footer/>
  </>;
};

export default EmeraldGemstoneEarrngHomepg;
