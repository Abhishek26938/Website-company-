import React from 'react'

const RubyGemstoneEarringTextaboutpro = () => {
  return (
    <>
      <p style={{margin: "30px"}}>Preset ruby earrings are one of the top-selling and trending accessories that you should consider for yourself! Get blown away by the gorgeousness of the ruby. The symbol of love, passion, wealth and success, the ruby earrings are here to make you feel special whenever you wear them!</p>
    </>
  )
}

export default RubyGemstoneEarringTextaboutpro
