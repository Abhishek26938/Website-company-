import React from "react";
import RubyGemstoneEarringImageandtypes from "./RubyGemstone Earring product image and Details/RubyGemstoneEarringImageandtypes";
import Navbarpage from "../Homepage/Navbarpage/Navbarpage";
import RubyGemstoneEarringCookiesprodcut from './Ruby Gemstone Earring Cookies product/RubyGemstoneEarringCookiesprodcut'
import RubyGemstoneEarringAboutDetails from './Ruby Gemstone  Earring about Product Details/RubyGemstoneEarringAboutDetails'
import ImportantFact from "../OneProduct/Important Facts/ImportantFact";
import RubyGemstoneEarringTextaboutpro from './Ruby Gemstone Earring text porduct/RubyGemstoneEarringTextaboutpro'
import Footer from "../Homepage/Footer/Footer";

const RubyGemstoneEarringFromprodcutAllFile = () => {
  return (
    <>
      <Navbarpage />
      <RubyGemstoneEarringImageandtypes />
      <RubyGemstoneEarringCookiesprodcut/>
      <RubyGemstoneEarringAboutDetails/>
      <ImportantFact/>
      <RubyGemstoneEarringTextaboutpro/>
      <Footer/>
    </>
  );
};

export default RubyGemstoneEarringFromprodcutAllFile;
