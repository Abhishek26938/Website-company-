import React from 'react'
import Navbarpage from '../Homepage/Navbarpage/Navbarpage'
import SingleimageandDetailRingProduct from './Single Ring product Ring image and Details/SingleimageandDetailRingProduct'
import ImportantFact from '../OneProduct/Important Facts/ImportantFact'
import Footer from '../Homepage/Footer/Footer'
import CookingProdcutofSingle from './Cookoing product of single page/CookingProdcutofSingle'
import SingleProductDetailsFile from './Single Product details and product info/SingleProductDetailsFile'
import SingProdcutTestinring from './single-product-text-in-ring/SingProdcutTestinring'

const SingleRingProductpagForAllFile = () => {
  return (
    <>
 <Navbarpage/>
 <SingleimageandDetailRingProduct/>
 <CookingProdcutofSingle/>
 <SingleProductDetailsFile/>
 <ImportantFact/>
 <SingProdcutTestinring/>
 <Footer/>
    </>
  )
}

export default SingleRingProductpagForAllFile
