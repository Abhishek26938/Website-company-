import React from 'react'
import './Singleprodcut.css'

const SingProdcutTestinring = () => {
  return (
    <>
     <p className='What-sthe-classic-sapphire' > What's the classic sapphire jewelry that you can never go wrong with? It's the preset sapphire rings. To add a touch of glamour to your whole look you should have a sapphire ring in your vanity. Get mesmerized in the presence of the stunning sapphire ring. Make customization as required. </p>
    </>
  )
}

export default SingProdcutTestinring
