import React from 'react'
import Navbarpage from '../Homepage/Navbarpage/Navbarpage'
import BlueSapphireRingHomePageLink from '../Blue sapphire fold in home page link/Blue sapphire Ring  Product/BlueSapphireRingHomePagelink'
import Footer from '../Homepage/Footer/Footer'
import BluePandntfromHomepage  from './Blue Sapphire Pandant from Home/BluePandntfromHomepage '

const BlueSapphirePandantfromHome = () => {
  return (
    <>
     <Navbarpage/>
     <BlueSapphireRingHomePageLink/>
    <BluePandntfromHomepage />
     <Footer/>
    </>
  )
}

export default BlueSapphirePandantfromHome
