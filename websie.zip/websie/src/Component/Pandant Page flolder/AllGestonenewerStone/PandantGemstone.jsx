import React from "react";
import Allgemstonenewer from "../../Commonnd/Gesmtoneshopall/Allgemstonenewer";

const PandantGemstone = () => {
 
  return (
    <>
      <Allgemstonenewer
        name="Pandant"
        discription="Explore a breathtaking variety of pendants on sale. Buy gemstone pendants online with confidence from our inventory of over 50000 certified gemstones" 
      />
    </>
  );
};

export default PandantGemstone;
