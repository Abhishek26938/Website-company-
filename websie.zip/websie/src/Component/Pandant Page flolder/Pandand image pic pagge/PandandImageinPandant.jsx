import React from 'react'
import Imagesringpendantearring from '../../Commonnd/Imagesofearringringpandand/Imagesringpendantearring'

const PandandImageinPandant = () => {
  return (
    <>
      <Imagesringpendantearring 
  Name = "Pendant" Description = "Buy necklace online from our curated collection of popular sapphire, ruby and emerald pendants" 
      visite1 ="/"  Name1="Sapphire Rings" image1 ="https://d3kinlcl20pxwz.cloudfront.net/images/home_new/sapphire-pendant-cover-preset.jpg?format=webp" 
      visite2 ="/"  Name2="Ruby Ring " image2 ="https://d3kinlcl20pxwz.cloudfront.net/images/home_new/ruby-pendant-cover-preset.jpg?format=webp"
      visite3 ="/"  Name3="Emerald" image3 ="https://d3kinlcl20pxwz.cloudfront.net/images/home_new/emerald-pendant-cover-preset.jpg?format=webp"
      />
    </>
  )
}

export default PandandImageinPandant
