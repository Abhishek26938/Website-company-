import React from 'react'
import Imagesringpendantearring from '../../Commonnd/Imagesofearringringpandand/Imagesringpendantearring'

const PresetEarringCollection = () => {
  return (
    <>
     <Imagesringpendantearring  Name = "Earring" Description = "Buy earrings online from our curated collection of popular sapphire, ruby and emerald gemstone studs"
      visite1 ="/"  Name1="Sapphire Earrings" image1 ="https://d3kinlcl20pxwz.cloudfront.net/images/home_new/preset_sapphire-earring-image2.jpg?format=webp" 
      visite2 ="/"  Name2="Ruby Earrings " image2 ="https://d3kinlcl20pxwz.cloudfront.net/images/home_new/preset_ruby-earring-image.jpg?format=webp"
      visite3 ="/"  Name3="Emerald Earrings" image3 ="https://d3kinlcl20pxwz.cloudfront.net/images/home_new/preset_emerald-earring-image-2.jpg?format=webp"
 />
    </>
  )
}

export default PresetEarringCollection
