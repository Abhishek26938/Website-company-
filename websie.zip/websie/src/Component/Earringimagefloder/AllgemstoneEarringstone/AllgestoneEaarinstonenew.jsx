import React from 'react'
import './AllgestoneEarring.css'
import Allgemstonenewer from "../../Commonnd/Gesmtoneshopall/Allgemstonenewer"

const AllgestoneEaarinstonenew = () => {
  return (
    <>    
 <Allgemstonenewer name = "Bracelets" discription ='A breathtaking variety of bracelets on sale. Buy gemstone bracelets online with confidence from our inventory of over 50000 certified gemstones' />
</>
    
  )
}

export default AllgestoneEaarinstonenew
