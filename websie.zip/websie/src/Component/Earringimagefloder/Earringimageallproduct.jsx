import React from "react";
import Earringimageheader from "./Earringimageofheader/Earringimageheader";
import Navbarpage from "../Homepage/Navbarpage/Navbarpage";
import Fixcebleprinceline from ".././Ringproductimagepage/fixcebleprince/Fixcebleprinceline";
import AllgestoneEaarinstonenew from "./AllgemstoneEarringstone/AllgestoneEaarinstonenew";
import GemstoneallImagestone from "../Ringproductimagepage/Gemstoneallimagestone/GemstoneallImagestone";
import PresetEarringCollection from "./Preset Earrings Collection/PresetEarringCollection";
import Butdirectnomiddle from "../Ringproductimagepage/BuyDirectNoMiddle/Butdirectnomiddle";
import Flexiblefinancingpagenewring from "../Ringproductimagepage/flexiblefinancingnewpage/Flexiblefinancingpagenewringpage";
import ShopmetalpageRing from "../Ringproductimagepage/ShopMetalRingPage/ShopmetalpageRing";
import ConsultOurJewleryRingPage from "../Ringproductimagepage/Consult Our Jewelry/ConsultOurJewleryRingPage";
import Footer from "../Homepage/Footer/Footer";
import StyleEarringData from "./Shop Earring By Style/StyleEarringData";
import ShopPopularEarring from "./Shop Popular Earring Designs/ShopPopularEarring";

const Earringimageallproduct = () => {
  return (
    <>
      <Navbarpage />
      <Earringimageheader />
      <Fixcebleprinceline />
      <AllgestoneEaarinstonenew />
      <GemstoneallImagestone />
      <PresetEarringCollection />
      <StyleEarringData />
      <Butdirectnomiddle />
      <ShopPopularEarring />
      <Flexiblefinancingpagenewring />
      <ShopmetalpageRing />
      <ConsultOurJewleryRingPage />
      <Footer />
    </>
  );
};

export default Earringimageallproduct;
