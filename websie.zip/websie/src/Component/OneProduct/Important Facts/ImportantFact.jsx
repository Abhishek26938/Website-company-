// import React from "react";
// import './ImportantFacts.css'

// const ImportantFact = () => {
//   return (
//     <>
//       {/*------------------------------------ Important Facts Before Your Purchase ----------------------------------*/}
//       {/*------------------------------------ Important Facts Before Your Purchase ----------------------------------*/}
//       <div className="important-facts">
//         <div className="important-facts-before">
//           <h3 className="importan-befor">
//             Important Facts Before Your Purchase
//           </h3>
//           <div className="IMPortant-facts-purchase">
//             <div className="PurchaseShipping">
//               <div className="PurchaseShipping_icon">
//                 <img
//                   src="https://d3kinlcl20pxwz.cloudfront.net/images/icon_shipping.svg"
//                   alt="Icon_shipping"
//                   role="presentation"
//                 />
//               </div>
//               <div className="titlesPurchase">
//                 {" "}
//                 <span>Shipping</span>
//                 <ul>
//                   <li>Free Domestics FedEx Shipping </li>
//                   <li>$50 FedEx International Shipping Fee</li>
//                   <li>All Packages require Signature</li>
//                   <li className="latchild">
//                     {" "}
//                     <a href="#">Click for Full Shipping Policy</a>
//                   </li>
//                 </ul>
//               </div>
//             </div>
//             <div className="PurchaseShipping">
//               <div className="PurchaseShipping_icon">
//                 <img
//                   src="https://d3kinlcl20pxwz.cloudfront.net/images/payment_accepted.svg"
//                   width={60}
//                   height={60}
//                   alt="Payments Accepted"
//                   role="presentation"
//                 />
//               </div>
//               <div className="titlesPurchase">
//                 {" "}
//                 <span>Payments Accepted</span>
//                 <ul>
//                   <li>
//                     Credit / Debit Card{" "}
//                     <span>(Visa, Mastercard, Discover, American Express)</span>
//                   </li>
//                   <li>Wire Transfer</li>
//                   <li>Paypal Checkout</li>
//                   <li>Amazon Pay</li>
//                   <li className="latchild">
//                     <a href="https://www.gemsny.com/finance/">
//                       Flexible Financing{" "}
//                     </a>
//                   </li>
//                 </ul>
//               </div>
//             </div>
//             <div className="PurchaseShipping">
//               <div className="PurchaseShipping_icon">
//                 <img
//                   src="https://d3kinlcl20pxwz.cloudfront.net/images/return_policy.svg"
//                   width={60}
//                   height={60}
//                   alt="30 Day Return Policy"
//                   role="presentation"
//                 />
//               </div>
//               <div className="titlesPurchase">
//                 {" "}
//                 <span>30 Day Return Policy30 Day Return Policy</span>
//                 <ul>
//                   <li>Free Returns </li>
//                   <li>One Free Return label provided in 6 month period</li>
//                   <li>
//                     International customers will need to return at own expense.
//                   </li>
//                   <li className="latchild">
//                     {" "}
//                     <a href="#/">Click for Full Return Policy</a>
//                   </li>
//                 </ul>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//       {/* --------------------------------- Flexible Financing ------------------------------- */}
//       {/*--------------------------------- Flexible Financing -------------------------------*/}
//       <section>
//         <div className="cart-pic-to-know">
//           <div className="flexibele_financing-with">
//             <div className=" March-will-be">
//               <div className="flexible">
//                 <h1>Flexible Financing</h1>
//                 <div className="flexible_financing_img">
//                   <div className="affim">
//                     <img
//                       src="https://d3kinlcl20pxwz.cloudfront.net/imgs/main/affirm_icon.webp"
//                       alt=""
//                     />
//                     <span className="mothes_month">
//                       Up to 36 months financing available.
//                     </span>
//                     <a href="#">Learn more</a>
//                   </div>
//                   <div className="affim">
//                     <img
//                       src="https://d3kinlcl20pxwz.cloudfront.net/imgs/main/splitit_icon.webp"
//                       alt=""
//                     />
//                     <span className="mothes_month">
//                       Choose from 3, 6, 9 or 12 months interest <br /> free
//                       payments at checkout.
//                     </span>
//                     <a href="#">Learn more</a>
//                   </div>
//                   <div className="affim">
//                     <img
//                       src="https://d3kinlcl20pxwz.cloudfront.net/imgs/main/layway_icon.webp"
//                       alt=""
//                     />
//                     <span className="mothes_month">
//                       Layaway options are available. Contact <br /> us at{" "}
//                       <a href="#">info@gemsny.com</a>
//                     </span>
//                     <a href="#">Learn more</a>
//                   </div>
//                 </div>
//               </div>
//             </div>
//             <div className="learn-more-note">
//               <button>Learn More</button>
//               <div className="note-div-product">
//                 <p className="all-financing-iotion-we-be"></p>
//                 <h4>Note:</h4>All Financing options we be available at checkout
//                 <p />
//               </div>
//             </div>
//           </div>
//         </div>
//       </section>
//       {/*------------------------------------------------------------ gemsny advantegas of image  ----------------------*/}
//       {/*------------------------------------------------------------ gemsny advantegas of image  ----------------------*/}
//       <div className="advantages-of-image">
//         <h3 className="adavanteges-of-gesmany">GemsNY Advanteges</h3>
//         <div className="gesmany">
//           <img src="https://d3kinlcl20pxwz.cloudfront.net/images/GemsNY_dvantage_desktop.png"
//             alt="image"
//           />
//         </div>
//       </div>
//       {/*-------------------------------- custom Jewellery image of step by step --------------------------*/}
//       {/*-------------------------------- custom Jewellery image of step by step --------------------------*/}
//       <h3 className="costom-jewellery-by">costom Jewllery</h3>
//       <div className="ARROWring-flex">
//         <div className="arrow-with-img1">
//           <div className="coustom-jewellery-of">
//             <img
//               src="https://d3kinlcl20pxwz.cloudfront.net/images/Sketch.png"
//               alt=""
//             />
//           </div>
//           <div className="arrow-div-now">
//             <img
//               className="arroowpic"
//               src="/images/arrow-right-310628_1280-removebg-preview.png"
//               alt=""
//             />
//           </div>
//         </div>
//         <div className="arrow-with-img1">
//           <div className="coustom-jewellery-of">
//             <img
//               src="https://d3kinlcl20pxwz.cloudfront.net/images/Sketch.png"
//               alt=""
//             />
//           </div>
//           <div className="arrow-div-now">
//             <img
//               className="arroowpic"
//               src="/images/arrow-right-310628_1280-removebg-preview.png"
//               alt=""
//             />
//           </div>
//         </div>
//         <div className="arrow-with-img1">
//           <div className="coustom-jewellery-of">
//             <img
//               src="https://d3kinlcl20pxwz.cloudfront.net/images/Sketch.png"
//               alt=""
//             />
//           </div>
//           <div className="arrow-div-now">
//             <img
//               className="arroowpic"
//               src="/images/arrow-right-310628_1280-removebg-preview.png"
//               alt=""
//             />
//           </div>
//         </div>
//         <div className="arrow-with-img1">
//           <div className="coustom-jewellery-of">
//             <img
//               src="https://d3kinlcl20pxwz.cloudfront.net/images/Sketch.png"
//               alt=""
//             />
//           </div>
//         </div>
//       </div>
//       <p className="have-your-own-jewellery">
//         {" "}
//         Have Your Own Jewelry Idea, click here to{" "}
//         <a href="#">submit your request</a>
//       </p>
//     </>
//   );
// };

// export default ImportantFact;
