import { Link } from "react-router-dom";

export const prodcutDatafile = [{
    id : "1" ,
    Img : " https://d3kinlcl20pxwz.cloudfront.net/image-jewelry/EB74110BS/FM.jpg" ,
    price : "$656 -$1181",
    itemsqu : "Item#: EB70875YS" ,
    ProductDt : "Half Eternity Diamond And Blue Sapphire Round Layered Prong Wedding Ring", 
    caratgold : "18k White Gold",
    Link : "/GemstoneBandsproductallFilesto" ,
    nameofstone : "Blue Sapphire Details",
    NumberofstoneName  : "No. of Stone " ,
    Numberofstone : "8" ,
    StoneweightName : "Carat Weight" ,
    Stonecaratweight : "0.27",
    Diamondeofstone : "Diamont Details",
    NumberofDiamondName  : "No. of Stone " ,
    NumberofDimaond  : "8" ,
    DiamondweightName : "Carat Weight" ,
    Diamondcaratweight : "0.27",
  
},
{
    id : "2" ,
    Img : " https://d3kinlcl20pxwz.cloudfront.net/image-jewelry/EB74110BS/FM.jpg" ,
    price : "$656 -$1181",
    itemsqu : "Item#: EB70875YS" ,
    ProductDt : "Half Eternity Diamond And Blue Sapphire Round Layered Prong Wedding Ring",
    caratgold : "18k White Gold",
    Link : "/AddToCard" ,
    nameofstone : "Blue Sapphire Details",
    NumberofstoneName  : "No. of Stone " ,
    Numberofstone : "8" ,
    StoneweightName : "Carat Weight" ,
    Stonecaratweight : "0.27",
    Diamondeofstone : "Diamont Details",
    NumberofDiamondName  : "No. of Stone " ,
    NumberofDimaond  : "8" ,
    DiamondweightName : "Carat Weight" ,
    Diamondcaratweight : "0.27",

},
{
    id : "3" ,
    Img : " https://d3kinlcl20pxwz.cloudfront.net/image-jewelry/EB74110BS/FM.jpg" ,
    price : "$656 -$1181",
    itemsqu : "Item#: EB70875YS" ,
    ProductDt : "Half Eternity Diamond And Blue Sapphire Round Layered Prong Wedding Ring",
    caratgold : "18k White Gold",
    Link : "/Ringproduct" ,
     nameofstone : "Blue Sapphire Details",
    NumberofstoneName  : "No. of Stone " ,
    Numberofstone : "8" ,
    StoneweightName : "Carat Weight" ,
    Stonecaratweight : "0.27",
    Diamondeofstone : "Diamont Details",
    NumberofDiamondName  : "No. of Stone " ,
    NumberofDimaond  : "8" ,
    DiamondweightName : "Carat Weight" ,
    Diamondcaratweight : "0.27",

},
{
    id : "4" ,
    Img : " https://d3kinlcl20pxwz.cloudfront.net/image-jewelry/EB74110BS/FM.jpg" ,
    price : "$656 -$1181",
    itemsqu : "Item#: EB70875YS" ,
    ProductDt : "Half Eternity Diamond And Blue Sapphire Round Layered Prong Wedding Ring",
    caratgold : "18k White Gold",
    Link : "/LoginForm" ,
    nameofstone : "Blue Sapphire Details",
    NumberofstoneName  : "No. of Stone " ,
    Numberofstone : "8" ,
    StoneweightName : "Carat Weight" ,
    Stonecaratweight : "0.27",
    Diamondeofstone : "Diamont Details",
    NumberofDiamondName  : "No. of Stone " ,
    NumberofDimaond  : "8" ,
    DiamondweightName : "Carat Weight" ,
    Diamondcaratweight : "0.27",

},
{
    id : "5" ,
    Img : " https://d3kinlcl20pxwz.cloudfront.net/image-jewelry/EB74110BS/FM.jpg" ,
    price : "$656 -$1181",
    itemsqu : "Item#: EB70875YS" ,
    ProductDt : "Half Eternity Diamond And Blue Sapphire Round Layered Prong Wedding Ring",
    caratgold : "18k White Gold",
    Link : "/LoginForm" ,
    nameofstone : "Blue Sapphire Details",
    NumberofstoneName  : "No. of Stone " ,
    Numberofstone : "8" ,
    StoneweightName : "Carat Weight" ,
    Stonecaratweight : "0.27",
    Diamondeofstone : "Diamont Details",
    NumberofDiamondName  : "No. of Stone " ,
    NumberofDimaond  : "8" ,
    DiamondweightName : "Carat Weight" ,
    Diamondcaratweight : "0.27",

},
{
    id : "6" ,
    Img : " https://d3kinlcl20pxwz.cloudfront.net/image-jewelry/EB74110BS/FM.jpg" ,
    price : "$656 -$1181",
    itemsqu : "Item#: EB70875YS" ,
    ProductDt : "Half Eternity Diamond And Blue Sapphire Round Layered Prong Wedding Ring",
    caratgold : "18k White Gold",
    Link : "/LoginForm",
    nameofstone : "Blue Sapphire Details",
    NumberofstoneName  : "No. of Stone " ,
    Numberofstone : "8" ,
    StoneweightName : "Carat Weight" ,
    Stonecaratweight : "0.27",
    Diamondeofstone : "Diamont Details",
    NumberofDiamondName  : "No. of Stone " ,
    NumberofDimaond  : "8" ,
    DiamondweightName : "Carat Weight" ,
    Diamondcaratweight : "0.27",

},
{
    id : "7" ,
    Img : " https://d3kinlcl20pxwz.cloudfront.net/image-jewelry/EB74110BS/FM.jpg" ,
    price : "$656 -$1181",
    itemsqu : "Item#: EB70875YS" ,
    ProductDt : "Half Eternity Diamond And Blue Sapphire Round Layered Prong Wedding Ring",
    caratgold : "18k White Gold",
    Link : "/LoginForm",
     nameofstone : "Blue Sapphire Details",
    NumberofstoneName  : "No. of Stone " ,
    Numberofstone : "8" ,
    StoneweightName : "Carat Weight" ,
    Stonecaratweight : "0.27",
    Diamondeofstone : "Diamont Details",
    NumberofDiamondName  : "No. of Stone " ,
    NumberofDimaond  : "8" ,
    DiamondweightName : "Carat Weight" ,
    Diamondcaratweight : "0.27",

},
{
    id : "8" ,
    Img : " https://d3kinlcl20pxwz.cloudfront.net/image-jewelry/EB74110BS/FM.jpg" ,
    price : "$656 -$1181",
    itemsqu : "Item#: EB70875YS" ,
    ProductDt : "Half Eternity Diamond And Blue Sapphire Round Layered Prong Wedding Ring",
    caratgold : "18k White Gold",
    Link : "/LoginForm",
    nameofstone : "Blue Sapphire Details",
    NumberofstoneName  : "No. of Stone " ,
    Numberofstone : "8" ,
    StoneweightName : "Carat Weight" ,
    Stonecaratweight : "0.27",
    Diamondeofstone : "Diamont Details",
    NumberofDiamondName  : "No. of Stone " ,
    NumberofDimaond  : "8" ,
    DiamondweightName : "Carat Weight" ,
    Diamondcaratweight : "0.27",

}]

export const newDatanext = [{

    id : "1" ,
    Img : " https://d3kinlcl20pxwz.cloudfront.net/image-jewelry/EB74110BS/FM.jpg" ,
    price : "$656 -$1181",
    itemsqu : "Item#: EB70875YS" ,
    ProductDt : "Half Eternity Diamond And Blue Sapphire Round Layered Prong Wedding Ring",
    caratgold : "18k White Gold",
    Link : "/",
    nameofstone : "Blue Sapphire Details",
    NumberofstoneName  : "No. of Stone " ,
    Numberofstone : "8" ,
    StoneweightName : "Carat Weight" ,
    Stonecaratweight : "0.27",
    Diamondeofstone : "Diamont Details",
    NumberofDiamondName  : "No. of Stone " ,
    NumberofDimaond  : "8" ,
    DiamondweightName : "Carat Weight" ,
    Diamondcaratweight : "0.27",
    


}
,{
    id : "2" ,
    Img : " https://d3kinlcl20pxwz.cloudfront.net/image-jewelry/EB74110BS/FM.jpg" ,
    price : "$656 -$1181",
    itemsqu : "Item#: EB70875YS" ,
    ProductDt : "Half Eternity Diamond And Blue Sapphire Round Layered Prong Wedding Ring",
    caratgold : "18k White Gold",
    Link : "/", 
    nameofstone : "Blue Sapphire Details",
    NumberofstoneName  : "No. of Stone " ,
    Numberofstone : "8" ,
    StoneweightName : "Carat Weight" ,
    Stonecaratweight : "0.27",
    Diamondeofstone : "Diamont Details",
    NumberofDiamondName  : "No. of Stone " ,
    NumberofDimaond  : "8" ,
    DiamondweightName : "Carat Weight" ,
    Diamondcaratweight : "0.27",
   


 }]
// // {
// //     id : "11" ,
// //     Img : " https://d3kinlcl20pxwz.cloudfront.net/image-jewelry/EB74110BS/FM.jpg" ,
// //     price : "$656 -$1181",
// //     itemsqu : "Item#: EB70875YS" ,
// //     ProductDt : "Half Eternity Diamond And Blue Sapphire Round Layered Prong Wedding Ring",
// //     caratgold : "18k White Gold",
// //     Link : "/"

// // },
// // {
// //     id : "12" ,
// //     Img : " https://d3kinlcl20pxwz.cloudfront.net/image-jewelry/EB74110BS/FM.jpg" ,
// //     price : "$656 -$1181",
// //     itemsqu : "Item#: EB70875YS" ,
// //     ProductDt : "Half Eternity Diamond And Blue Sapphire Round Layered Prong Wedding Ring",
// //     caratgold : "18k White Gold",
// //     Link : "/"

// // },
// // {
// //     id : "13" ,
// //     Img : " https://d3kinlcl20pxwz.cloudfront.net/image-jewelry/EB74110BS/FM.jpg" ,
// //     price : "$656 -$1181",
// //     itemsqu : "Item#: EB70875YS" ,
// //     ProductDt : "Half Eternity Diamond And Blue Sapphire Round Layered Prong Wedding Ring",
// //     caratgold : "18k White Gold",
// //     Link : "/"

// // },
// // {
// //     id : "14" ,
// //     Img : " https://d3kinlcl20pxwz.cloudfront.net/image-jewelry/EB74110BS/FM.jpg" ,
// //     price : "$656 -$1181",
// //     itemsqu : "Item#: EB70875YS" ,
// //     ProductDt : "Half Eternity Diamond And Blue Sapphire Round Layered Prong Wedding Ring",
// //     caratgold : "18k White Gold",
// //     Link : "/"

// // },
// // {
// //     id : "15" ,
// //     Img : " https://d3kinlcl20pxwz.cloudfront.net/image-jewelry/EB74110BS/FM.jpg" ,
// //     price : "$656 -$1181",
// //     itemsqu : "Item#: EB70875YS" ,
// //     ProductDt : "Half Eternity Diamond And Blue Sapphire Round Layered Prong Wedding Ring",
// //     caratgold : "18k White Gold",
// //     Link : "/"

// // },
// // {
// //     id : "16" ,
// //     Img : " https://d3kinlcl20pxwz.cloudfront.net/image-jewelry/EB74110BS/FM.jpg" ,
// //     price : "$656 -$1181",
// //     itemsqu : "Item#: EB70875YS" ,
// //     ProductDt : "Half Eternity Diamond And Blue Sapphire Round Layered Prong Wedding Ring",
// //     caratgold : "18k White Gold",
// //     Link : "/"

// // },
// // {
// //     id : "17" ,
// //     Img : " https://d3kinlcl20pxwz.cloudfront.net/image-jewelry/EB74110BS/FM.jpg" ,
// //     price : "$656 -$1181",
// //     itemsqu : "Item#: EB70875YS" ,
// //     ProductDt : "Half Eternity Diamond And Blue Sapphire Round Layered Prong Wedding Ring",
// //     caratgold : "18k White Gold",
// //     Link : "/"

// // },
// // {
// //     id : "18" ,
// //     Img : " https://d3kinlcl20pxwz.cloudfront.net/image-jewelry/EB74110BS/FM.jpg" ,
// //     price : "$656 -$1181",
// //     itemsqu : "Item#: EB70875YS" ,
// //     ProductDt : "Half Eternity Diamond And Blue Sapphire Round Layered Prong Wedding Ring",
// //     caratgold : "18k White Gold",
// //     Link : "/"

// // },
// // {
// //     id : "19" ,
// //     Img : " https://d3kinlcl20pxwz.cloudfront.net/image-jewelry/EB74110BS/FM.jpg" ,
// //     price : "$656 -$1181",
// //     itemsqu : "Item#: EB70875YS" ,
// //     ProductDt : "Half Eternity Diamond And Blue Sapphire Round Layered Prong Wedding Ring",
// //     caratgold : "18k White Gold",
// //     Link : "/"

// // },
// // {
// //     id : "20" ,
// //     Img : " https://d3kinlcl20pxwz.cloudfront.net/image-jewelry/EB74110BS/FM.jpg" ,
// //     price : "$656 -$1181",
// //     itemsqu : "Item#: EB70875YS" ,
// //     ProductDt : "Half Eternity Diamond And Blue Sapphire Round Layered Prong Wedding Ring",
// //     caratgold : "18k White Gold",
// //     Link : "/"

// // },





