import React from 'react'

const EarringGemstoneLastAbout = () => {
  return (
    <>
    <p style={{margin: "30px"}}>  Looking for a statement sapphire earring? It is said 'Every new day is a fresh chance to glitter'. Sapphire earrings are definitely the sparkle you need in life. Earrings give the  <br /> finishing touch to any outfit. If you want to spice up your attire, sapphire earrings are your calling!</p>
    </>
  )
}

export default EarringGemstoneLastAbout
