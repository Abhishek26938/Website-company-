
export const EmeraldPandantCookesProductData= [{
    id : "1" ,
    imageCoocking : "https://d3kinlcl20pxwz.cloudfront.net/image-jewelry/PEM005-5X5-A/WHITEGOLD/FL.jpg" ,
    CookiesDsp : `Petite Prong Set Round Blue  ${<br />} Sapphire Hidden Halo Ring(0.74cttw)` ,
    Cookesicode : "RBS035" ,
    Cookiesmainp : "541",
    CookesDealp : "1,041 ",
    ProducutLink : "/"
},
{
    id : "2" ,
    imageCoocking : "https://d3kinlcl20pxwz.cloudfront.net/image-jewelry/PEM005-5X5-A/WHITEGOLD/FL.jpg" ,
    CookiesDsp : `Petite Prong Set Round Blue  ${<br />} Sapphire Hidden Halo Ring(0.74cttw)` ,
    Cookesicode : "RBS035" ,
    Cookiesmainp : "541",
    CookesDealp : "1,041 ",
    ProducutLink : "/"
},
{
    id : "3 " ,
    imageCoocking : "https://d3kinlcl20pxwz.cloudfront.net/image-jewelry/PEM005-5X5-A/WHITEGOLD/FL.jpg" ,
    CookiesDsp : `Petite Prong Set Round Blue  ${<br />} Sapphire Hidden Halo Ring(0.74cttw)` ,
    Cookesicode : "RBS035" ,
    Cookiesmainp : "541",
    CookesDealp : "1,041 ",
    ProducutLink : "/"
},
{
    id : "4 " ,
    imageCoocking : "https://d3kinlcl20pxwz.cloudfront.net/image-jewelry/PEM005-5X5-A/WHITEGOLD/FL.jpg" ,
    CookiesDsp : `Petite Prong Set Round Blue  ${<br />} Sapphire Hidden Halo Ring(0.74cttw)` ,
    Cookesicode : "RBS035" ,
    Cookiesmainp : "541",
    CookesDealp : "1,041 ",
    ProducutLink : "/"
},
{
    id : "5" ,
    imageCoocking : "https://d3kinlcl20pxwz.cloudfront.net/image-jewelry/PEM005-5X5-A/WHITEGOLD/FL.jpg" ,
    CookiesDsp : `Petite Prong Set Round Blue  ${<br />} Sapphire Hidden Halo Ring(0.74cttw)` ,
    Cookesicode : "RBS035" ,
    Cookiesmainp : "541",
    CookesDealp : "1,041 ",
    ProducutLink : "/"
},
{
    id : "6 " ,
    imageCoocking : "https://d3kinlcl20pxwz.cloudfront.net/image-jewelry/PEM005-5X5-A/WHITEGOLD/FL.jpg" ,
    CookiesDsp : `Petite Prong Set Round Blue  ${<br />} Sapphire Hidden Halo Ring(0.74cttw)` ,
    Cookesicode : "RBS035" ,
    Cookiesmainp : "541",
    CookesDealp : "1,041 ",
    ProducutLink : "/"
},
]


