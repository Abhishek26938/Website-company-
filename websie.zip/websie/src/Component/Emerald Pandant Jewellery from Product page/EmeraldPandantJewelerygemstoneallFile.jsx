import React from 'react'
import EemraldProdantjewelleryimageandtypeprodcut from './Emerald Pandant jewellery image and type of produt/EemraldProdantjewelleryimageandtypeprodcut'
import Navbarpage from '../Homepage/Navbarpage/Navbarpage'
import EmeraldGemstonePandantCookies from './Emerald Gmestone Pandatn Coockies Product/EmeraldGemstonePandantCookies'
import EmeraldPandantGemstoneabout from './Emerald Pandant Gemstone about of prodcut/EmeraldPandantGemstoneabout'
import Footer from '../Homepage/Footer/Footer'
import ImportantFact from '../OneProduct/Important Facts/ImportantFact'

const EmeraldPandantJewelerygemstoneallFile = () => {
  return (
    <>
    <Navbarpage/>
      <EemraldProdantjewelleryimageandtypeprodcut/>
      <EmeraldGemstonePandantCookies/>
      <EmeraldPandantGemstoneabout/>
      <ImportantFact/>
      <Footer/>
    </>
  )
}

export default EmeraldPandantJewelerygemstoneallFile
